<div class="page-footer">


    <div class="page-footer-inner"> 2022 © &nbsp; <a href="https://www.orien.ge/" class="font-white" target="_blank">orien.ge</a> </div>


    <div class="scroll-to-top">


        <i class="icon-arrow-up"></i>


    </div>


</div>


<!--[if lt IE 9]>


    <script src="{{ url('assets/nn_cms/global/plugins/respond.min.js') }}" type="text/javascript"></script>


    <script src="{{ url('assets/nn_cms/global/plugins/excanvas.min.js') }}" type="text/javascript"></script> 


<![endif]-->


<!-- BEGIN CORE PLUGINS -->


<script src="{{ url('assets/nn_cms/global/plugins/jquery.min.js') }}" type="text/javascript"></script>
<script src="{{ url('assets/nn_cms/global/plugins/js.cookie.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js') }}" type="text/javascript"></script>


{{-- <script src="{{ url('assets/nn_cms/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js') }}" type="text/javascript"></script> --}}


<script src="{{ url('assets/nn_cms/global/plugins/jquery.blockui.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/uniform/jquery.uniform.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js') }}" type="text/javascript"></script>


<!-- END CORE PLUGINS -->


<!-- BEGIN PAGE LEVEL PLUGINS -->


<script src="{{ url('assets/nn_cms/global/plugins/bootstrap-daterangepicker/moment.min.js') }}" type="text/javascript"></script>

<script src="{{ url('assets/nn_cms/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js') }}" type="text/javascript"></script>
<script src="{{ url('assets/nn_cms/global/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js') }}" type="text/javascript"></script>
<script src="{{ url('assets/nn_cms/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js') }}" type="text/javascript"></script>
<script src="{{ url('assets/nn_cms/assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js') }}" type="text/javascript"></script>
<script src="{{ url('assets/nn_cms/global/plugins/clockface/js/clockface.js') }}" type="text/javascript"></script>
<script src="{{ url('assets/nn_cms/pages/scripts/components-date-time-pickers.min.js') }}" type="text/javascript"></script>

<script src="{{ url('assets/nn_cms/global/plugins/bootstrap-daterangepicker/daterangepicker.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/morris/morris.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/morris/raphael-min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/counterup/jquery.waypoints.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/counterup/jquery.counterup.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/fullcalendar/fullcalendar.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/flot/jquery.flot.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/flot/jquery.flot.resize.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/global/plugins/flot/jquery.flot.categories.min.js') }}" type="text/javascript"></script>


{{-- <script src="{{ url('assets/nn_cms/global/plugins/jquery-easypiechart/jquery.easypiechart.min.js') }}" type="text/javascript"></script> --}}


<script src="{{ url('assets/nn_cms/global/plugins/jquery.sparkline.min.js') }}" type="text/javascript"></script>


<!-- END PAGE LEVEL PLUGINS -->


<!-- BEGIN THEME LAYOUT SCRIPTS  -->


<script src="{{ url('assets/nn_cms/layouts/layout/scripts/layout.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/layouts/layout/scripts/demo.min.js') }}" type="text/javascript"></script>


<script src="{{ url('assets/nn_cms/layouts/global/scripts/quick-sidebar.min.js') }}" type="text/javascript"></script>


<!-- END THEME LAYOUT SCRIPTS -->