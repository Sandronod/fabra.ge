﻿<script src="{{ url('assets/nn_cms/global/plugins/jquery.min.js') }}" type="text/javascript"></script>

<!-- END JQUERY -->

<!-- BEGIN THEME GLOBAL SCRIPTS -->

<script src="{{ url('assets/nn_cms/global/scripts/app.min.js') }}" type="text/javascript"></script>

<!-- END THEME GLOBAL SCRIPTS -->

@stack('scripts')