<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <h2>Your have registered on pdfdraft, your password is below:</h2>
    <p>Password: {{$hashedRandomPassword}}</p>
  </body>
</html>