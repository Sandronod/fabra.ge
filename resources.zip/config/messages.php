<?php

return [

    'NEW_JOB_IN_YOUR_CATEGORY' => 0,
    'SOMEONE_REQUESTED_MAKE_JOB' => 1,

];
