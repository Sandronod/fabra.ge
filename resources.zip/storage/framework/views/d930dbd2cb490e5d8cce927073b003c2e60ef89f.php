﻿<script src="<?php echo e(url('assets/nn_cms/global/plugins/jquery.min.js')); ?>" type="text/javascript"></script>

<!-- END JQUERY -->

<!-- BEGIN THEME GLOBAL SCRIPTS -->

<script src="<?php echo e(url('assets/nn_cms/global/scripts/app.min.js')); ?>" type="text/javascript"></script>

<!-- END THEME GLOBAL SCRIPTS -->

<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH C:\xampp\htdocs\fabra.ge\resources\views/nn_cms/partials/scripts.blade.php ENDPATH**/ ?>