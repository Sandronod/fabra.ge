<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="" />
<meta name="email" content="" />
<meta name="website" content="fabra.ge" />
<meta name="Version" content="v1.0.0" />
<?php /**PATH C:\xampp\htdocs\fabra.ge\resources\views/nn_site/partials/head_tags.blade.php ENDPATH**/ ?>