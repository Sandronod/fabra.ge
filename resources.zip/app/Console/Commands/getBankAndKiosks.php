<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Http\Controllers\nn_site\CurrenciesApi;

class getBankAndKiosks extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:getBankAndKiosks';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        CurrenciesApi::get();
    }
}
