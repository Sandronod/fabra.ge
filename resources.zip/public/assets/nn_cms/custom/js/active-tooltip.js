$(function(){
    $("[rel='tooltip']").tooltip();
});