$(function(){
    $(".filemanager-btn").filemanager("file");
});